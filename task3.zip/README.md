
# Task 3 - SQL Data Extraction

## Objective
Extract data from one or more tables using SQL clauses such as SELECT, WHERE, ORDER BY, and LIMIT.

## Queries Included
- Selecting all and specific columns
- Filtering data using WHERE, AND, OR, LIKE, and BETWEEN
- Sorting data using ORDER BY
- Limiting the number of output rows using LIMIT

## Tools Used
- DB Browser for SQLite / MySQL Workbench

## Output
The SQL queries included in `task3.sql` demonstrate data extraction from an `employees` table.
