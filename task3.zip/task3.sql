
-- Select all columns from employees table
SELECT * FROM employees;

-- Select specific columns
SELECT first_name, last_name, salary FROM employees;

-- Apply WHERE condition
SELECT * FROM employees WHERE department = 'HR';

-- Using AND, OR, LIKE, BETWEEN
SELECT * FROM employees WHERE department = 'Sales' AND salary BETWEEN 40000 AND 60000;
SELECT * FROM employees WHERE last_name LIKE 'S%';

-- Sorting and limiting results
SELECT * FROM employees ORDER BY salary DESC LIMIT 5;
